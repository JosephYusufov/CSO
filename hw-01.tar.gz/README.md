# Computer Systems Organization
Joseph Yusufov

NYU - Spring 2021

Prof. Alan Gottleib

Rec. Leader: Arhant Kumar

## Instructions
* Extract the archive
* run `make`
* run `./homework.exe sampleText.exe`
